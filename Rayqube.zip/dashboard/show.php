
<?php include 'includes/connection.php'; ?>

<?php include 'includes/adminheader.php';
?>
<?php 
if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {

header("location: index.php");
}
?>
    <div id="wrapper">
<?php ?>
       <?php include 'includes/adminnav.php';?>
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                        <div class="col-xs-4">
            <a href="uploadnote.php" class="btn btn-primary">Add New Project</a>
            </div>
                         MY Project
                        </h1>
                         
<div class="row">
<div class="col-lg-12">
        <div class="table-responsive">

<form action="" method="post">
            <table class="table table-bordered table-striped table-hover">


            <thead>
                    <tr>
                       <th>name</th>
                         <th>Priority</th>
                        <th>Subject</th>
                        <th>Task/Message</th>
                        
                        
                    </tr>
                </thead>
                <tbody>

                 <?php
                    
                 $currentuser = $_SESSION['username'];

$query = "SELECT * FROM message WHERE username= '$currentuser' ";
$run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
if (mysqli_num_rows($run_query) > 0) {
while ($row = mysqli_fetch_array($run_query)) {
    $username = $row['username'];
    /* $email = $row['email'];*/
      $priority = $row['priority'];
    $Subject = $row['subject'];
    
    $message= $row['message'];
    

    echo "<tr>";
    echo "<td>$username</td>";
       echo "<td>$priority</td>";
         /*  if($priority = "1")
    {
     echo "<td>High</td>";
    }
    else{
        echo "<td>Low</td>";
    }*/
      echo "<td>$Subject</td>";
    echo "<td>$message</td>";
    
    
   echo "</tr>";

}
}
else {
    echo "<script>alert('No message');
    window.location.href= 'show.php';</script>";
}
?>


                </tbody>
            </table>
</form>
</div>
</div>
</div>
 


 <script src="js/jquery.js"></script>

    
    <script src="js/bootstrap.min.js"></script>

</body>

</html

