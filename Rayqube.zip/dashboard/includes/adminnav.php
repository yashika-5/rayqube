<style>
   .modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}

/* The Close Button */
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
</style>
 <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="statatics.php">Rayqube</a>
            </div>
     
     <ul  class="nav navbar-right top-nav"><button style="background-color:black; color:white; border-color:black" id="myBtn" class="navbar-brand" >Message</button></ul>
        
           <?php
     if (isset($_POST['submit'])) {
    echo $username=$_POST['username'];
         $priority = $_POST['priority'];
             $Subject=$_POST['Subject'];
             $message=$_POST['message'];
         
         
           
            $query=mysqli_query($conn,"INSERT INTO message (username,priority,Subject,message) VALUES ('$username','$priority','$Subject','$message')");
}
     ?>
          
                    <!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <p>Message</p>
   <div id="after_submit"></div>
<form id="contact_form" action="#" method="POST" enctype="multipart/form-data">
  <div class="row">
    <label class="required" for="name">username:</label><br />
    <input id="name" class="form-control" name="username" type="text" value="" size="30" /><br />
    <span id="name_validation" class="error_message"></span>
  </div>
    <div class="row">
    <label class="required" for="priority">priority:</label><br />
        <input type="radio" id="one" name="priority" value="High" size="17" checked>High
<input type="radio" id="zero" name="priority" value="Low" size="17" >Low     
    <span id="email_validation" class="error_message"></span>
  </div>
    <br>
  <div class="row">
    <label class="required" for="email">subject:</label><br />
    <input id="name" class="form-control" name="Subject" type="text" value="" size="30" /><br />
    <span id="email_validation" class="error_message"></span>
  </div>
    
  <div class="row">
    <label class="required" for="message">Your message:</label><br />
    <textarea id="message" class="form-control" name="message" rows="7" cols="30"></textarea><br />
    <span id="message_validation" class="error_message"></span>
  </div>
    
    <input id="submit_button" name="submit" class="btn" type="submit" value="Send message" />
</form>
    
  </div>

</div>
     <script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
     
     
     
     
    
     
     
     
            <ul class="nav navbar-right top-nav">
                <?php if($_SESSION['role'] !== 'admin') { ?> <li><a href="./uploadnote.php">Daily_log</a></li> <?php } ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION['name']; ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>"><i class="fa fa-fw fa-user"></i> Account</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>

<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="statatics.php" class="active"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                <?php if($_SESSION['role'] == 'admin') {
                    ?>
                   <li>
                         <a href="javascript:;" data-toggle="collapse" data-target="#user"><i class="fa fa-fw fa-users"></i> Users <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="user" class="collapse">
                            <li>
                                <a href="./users.php">View All Users</a>
                            </li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="collapse" data-target="#posts"><i class="fa fa-fw fa-file-text"></i> My Account <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="posts" class="collapse">
                            <li>
                                <a href="./viewprofile.php?name=<?php echo $_SESSION['username']; ?>"> View Profile</a>
                            </li>
                            <li>
                                <a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>">Edit Profile</a>
                            </li>
                        </ul>
                        </li>
                            
                    
                   
                     <li>
                        
                       <a href="../teamleader.php?name=<?php echo $_SESSION['username']; ?>"> Department</a>
                    </li>
                   
                        
                     <li>
                        
                       <a href="../middle.php?name=<?php echo $_SESSION['username']; ?>"> Daily_Log</a>
                    </li>
                        
                     <li>
                        
                       <a href="../adduser.php?name=<?php echo $_SESSION['username']; ?>"> ADD USer</a>
                    </li>
                        
                            
                    <?php } else { ?>

                    <li>
                         <a href="javascript:;" data-toggle="collapse" data-target="#user"><i class="fa fa-fw fa-users"></i> My Projects <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="user" class="collapse">
                            <li>
                                <a href="./notes.php">View All Projects</a>
                            </li>
                            <li>
                                <a href="./uploadnote.php">Upload Projects</a>
                                 <li>
                                <a href="./show.php">show message</a>
                            </li>
                            </li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="collapse" data-target="#posts"><i class="fa fa-fw fa-file-text"></i> My Account <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="posts" class="collapse">
                            <li>
                                <a href="./viewprofile.php?name=<?php echo $_SESSION['username']; ?>"> View Profile</a>
                            </li>
                            <li>
                                <a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>">Edit Profile</a>
                            </li>
                        </ul>
                        </li>
<li>
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="collapse" data-target="#info"><i class="fa fa-fw fa-file-text"></i> User_Info <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="info" class="collapse">
                            <li>
                                <a href="../signup.php?name=<?php echo $_SESSION['username']; ?>"> Personal Profile</a>
                            </li>
                            <li>
                                <a href="../techprofile.php?section=<?php echo $_SESSION['username']; ?>"> Technical Profile</a>
                            </li>
                        </ul>
                        </li>

     
     
<?php } ?>
                </ul>
            </div>
        </nav>