<?php include 'dashboard/includes/connection.php';?>
<?php include 'dashboard/includes/adminheader.php';?>

<?php include 'dashboard/includes/adminnav.php';?>
<head>
<script src="dashboard/js/tinymce/tinymce.min.js"></script>
    <script src="dashboard/js/tinymce/script.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/cms-home.css">
	<link rel="stylesheet" type="text/css" href="css/material-icons.css">
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
    <link rel="stylesheet" type="text/css" href="css/demo.css" media="all" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css">

    <link rel="stylesheet" href="css/loginstyle.css">
	<link href="dashboard/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>	

<?php
if (isset($_POST['signup'])) {
require "gump.class.php";
$gump = new GUMP();
$_POST = $gump->sanitize($_POST); 

$gump->validation_rules(array(
  'username'    => 'required|alpha_numeric|max_len,20|min_len,4',
  'name'        => 'required|alpha_space|max_len,30|min_len,5',
  'email'       => 'required|valid_email',

));
$gump->filter_rules(array(
  'username' => 'trim|sanitize_string',
  'name'     => 'trim|sanitize_string',
  'email'    => 'trim|sanitize_email',
  ));
$validated_data = $gump->run($_POST);

if($validated_data === false) {
  ?>
  <center><font color="red" > <?php echo $gump->get_readable_errors(true); ?> </font></center>
  <?php
}
/*else if ($_POST['password'] !== $_POST['repassword']) 
{
  echo  "<center><font color='red'>Passwords do not match </font></center>";
}*/
/*else {
      $username = $validated_data['username'];
      $checkusername = "SELECT * FROM users WHERE username = '$username'";
      $run_check = mysqli_query($conn , $checkusername) or die(mysqli_error($conn));
      $countusername = mysqli_num_rows($run_check); 
      if ($countusername > 0 ) {
    echo  "<center><font color='red'>Username is already taken! try a different one</font></center>";
}*/
/*$email = $validated_data['email'];
$checkemail = "SELECT * FROM users WHERE email = '$email'";
      $run_check = mysqli_query($conn , $checkemail) or die(mysqli_error($conn));
      $countemail = mysqli_num_rows($run_check); 
      if ($countemail > 0 ) {
    echo  "<center><font color='red'>Email is already taken! try a different one</font></center>";
}*/

  else {
   /*   $name = $validated_data['name'];
      $email = $validated_data['email'];*/
     /* $pass = $validated_data['password'];
      $password = password_hash("$pass" , PASSWORD_DEFAULT);*/
      $name=$_POST['name'];
      $email=$_POST['email'];
      $username=$_POST['username'];
        $ctech=$_POST['current_skills'];
        $ntech=$_POST['new_skills'];
       $switch=$_POST['switched_company'];
     
      $query = "INSERT INTO users(name,email,username,current_skills,new_skills,switched_company) VALUES ( '$name', '$email', '$username' , '$ctech' , '$ntech','$switch' )";
      $result = mysqli_query($conn , $query) or die(mysqli_error($conn));
      if (mysqli_affected_rows($conn) > 0) { 
        echo "<script>alert('SUCCESSFULLY REGISTERED');
        window.location.href='dashboared/index.php';</script>";
}
else {
  echo "<script>alert('Error Occured');</script>";
}
}
}

?>

<!---->
<?php

//$edit_id=$_GET['id']; 
/*
$query_d=mysqli_query($conn,"select * from users");
  
$query_data=mysqli_fetch_array($query_d);
if(isset($_REQUEST['submit'])){
     $edit_id=$_GET['id'];
$name = $_REQUEST['name'];
$lname = $_REQUEST['lname'];
$email = $_REQUEST['email'];
$password = $_REQUEST['password'];
$city = $_REQUEST['city'];
$mobile = $_REQUEST['mobile'];
 
  $query =  mysqli_query($connection,"update adminy set name='$name',lname='$lname',email='$email',city ='$city', mobile='$mobile' where id='$edit_id'");
    
 
    
    if($query)
    {
        echo "<script>window.location='user.php';</script>";
    }
    else
    {
        echo "<script>alert('value doest not submitted');</script>";
    }
    

}*/
?>



<br>

<div class="container">


      <div  class="form">
        <form id="contactform" method="POST"> 
          <p class="contact"><label for="name">Name</label></p> 
          <input id="name" name="name" placeholder="First and last name" required="" tabindex="1" type="text" > 
           
          <p class="contact"><label for="email">Email</label></p> 
          <input id="email" name="email" placeholder="example@domain.com" required="" type="email" > 
                
                <p class="contact"><label for="username">username</label></p> 
          <input id="username" name="username" placeholder="username" required="" tabindex="2" type="text" > 
           
                <p class="contact"><label for="ctech">Current Technology</label></p> 
          <input type="text" id="tech" name="current_skills" required=""> 
                <p class="contact"><label for="tech">New Technology</label></p> 
          <input type="text" id="ntech" name="new_skills" required=""> 
        
            <p class="contact"><label for="switched_company">Switched Company </label></p> 
            <input type="text" name="switched_company" id="company" required><br><br><br><br>
            
            <!--<p class="contact"><label for="role">I am a..</label></p> 
            <select class="select-style gender" name="role">
            <option value="employee">Employee</option>
            <option value="teamleader">Team Leader</option>
            </select><br><br>
            
            <p class="contact"><label for="course">Department</label></p>
            <input type="text" name="course" id="course" required><br><br>
            -->
            <input class="buttom" name="signup" id="submit" tabindex="5" value="Submit" type="submit">    
   </form> 
</div>      
</div>

</body>
</html>