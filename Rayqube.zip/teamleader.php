<?php include ('dashboard/includes/connection.php'); ?>
<?php include('dashboard/includes/adminheader.php');  ?>


<script src="js/jquery.js"></script>

    
    <script src="js/bootstrap.min.js"></script>
<head>

    <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<?php if($_SESSION['role'] == 'admin')  
{ 
	?>
	 <div id="wrapper">

    
    <?php include "dashboard/includes/adminnav.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                
                <div class="row">
                    <div class="col-lg-12">

                        
                        <h1 class="page-header">
                            All Users
                        </h1>



    <table class="table table-bordered table-hover">
    <thead>
        <tr>
            
            <th>Department</th>
            <th>Details</th>
            
        </tr>
    </thead>

    <tbody>
        
        <?php 
            
            $query = "SELECT DISTINCT file_uploaded_to FROM uploads";
            $select_users = mysqli_query($conn, $query) or die(mysqli_error($conn));
            if (mysqli_num_rows($select_users) > 0 ) {
            while ($row = mysqli_fetch_array($select_users)) {
                
                /*$user_role = $row['role'];*/
                $user_course = $row['file_uploaded_to'];
            
              
                echo "<td>$user_course</td>";
             /*   echo "<td>$Joindate</td>";*/
               
                echo "<td><a  href='sorted.php?delete=$user_course'><i class='fa fa-times fa-lg'></i>details</a></td>";
                echo "</tr>";
             }
        ?>

    </tbody>
 </table>

<?php 
}
   ?>
                        <?php
                        if (isset($_GET['delete'])) {
        $the_user_id = mysqli_real_escape_string($conn , $_GET['delete']);
       $query0 = "SELECT file_id FROM uploads WHERE file_id = '$the_user_id'";
        $result = mysqli_query($conn , $query0) or die(mysqli_error($conn));
        if (mysqli_num_rows($result) == 0 ) {
            echo "<script>alert('successfully');
            window.location.href= 'sorted.php';</script>";
        }
    }
}
    ?>

    

    </div>
    </div>
    </div>
    </div>

    </div>
    
</body>

</html>