<?php
include 'config.php';
include 'header.php';

?>
<html>

          
				<div class="card-box">
                                    <p class="text-muted font-14 m-b-20" style="color:black;">
                                        Data Of Registered User</p>
										<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg pull-right" data-toggle="modal" data-target="#myModal" style="margin-top:35px;">ADD USER </button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
 

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
         <form method="post">
  <div class="form-group">
    <label for="first">First Name :</label>
    <input type="text" class="form-control" id="email" name="name">
  </div>
  <div class="form-group">
    <label for="Last">Last Name :</label>
    <input type="text" class="form-control" id="email" name="lname">
  </div>
  <div class="form-group">
    <label for="email">E-mail:</label>
    <input type="email" class="form-control" id="email" name="email">
  </div>
  
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd" name="password">
  </div>
  
  <div class="form-group">
    <label for="City">City:</label>
    <input type="text" class="form-control" id="pwd" name="city">
  </div>
  <div class="form-group">
    <label for="Mobile">Mobile Number:</label>
    <input type="text" class="form-control" id="pwd" name="mobile">
  </div>
  
  <button type="submit" class="btn btn-success" name="submit">Submit</button>
</form> 
		
		
		
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
    </div>
</html>